#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "KWinX11::kwin" for configuration ""
set_property(TARGET KWinX11::kwin APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(KWinX11::kwin PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NOCONFIG "Qt6::Concurrent;Qt6::Sensors;Qt6::Svg;KF6::ColorScheme;KF6::ConfigGui;KF6::ConfigQml;KF6::Crash;KF6::GlobalAccel;KF6::I18n;KF6::I18nQml;KF6::Package;KF6::Service;KDecoration3::KDecoration;KDecoration3::KDecoration3Private;K::KGlobalAccelD;KF6::Notifications;Plasma::Activities;PW::KScreenLocker"
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libkwin-x11.so.6.4.3"
  IMPORTED_SONAME_NOCONFIG "libkwin-x11.so.6"
  )

list(APPEND _cmake_import_check_targets KWinX11::kwin )
list(APPEND _cmake_import_check_files_for_KWinX11::kwin "${_IMPORT_PREFIX}/lib/libkwin-x11.so.6.4.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
